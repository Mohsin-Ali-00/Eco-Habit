import React from 'react';

const About = () => {
  return (
    <div className="container py-5">
      <div className="text-center mb-4">
        <h2 className="display-5 fw-bold text-success">About Eco Habits</h2>
        <p className="text-muted lead">
          Building a greener tomorrow through everyday action, education, and digital skills.
        </p>
      </div>

      <div className="row g-4">
        <div className="col-md-6">
          <h4 className="text-success">🌱 Our Mission</h4>
          <p>
            Eco Habits is a digital awareness initiative aimed at empowering individuals with knowledge,
            motivation, and tools to adopt sustainable lifestyles. We believe small eco-friendly habits,
            when practiced daily, can create massive positive change for our planet.
          </p>
        </div>

        <div className="col-md-6">
          <h4 className="text-success">💻 Digital for the Environment</h4>
          <p>
            Our platform not only promotes green living but also encourages the use of digital tools, coding, 
            and art to amplify climate messages. We merge sustainability with 21st-century skills to make 
            eco-activism more creative and impactful.
          </p>
        </div>
      </div>

      <div className="mt-5 p-4 bg-light rounded shadow-sm">
        <h5 className="text-success">Why Eco Habits?</h5>
        <ul className="list-unstyled">
          <li>✅ Educates through Green Sessions and resources</li>
          <li>✅ Encourages real-world actions that lower CO₂ emissions</li>
          <li>✅ Inspires youth to lead climate-positive projects using tech</li>
        </ul>
      </div>
    </div>
  );
};

export default About;
