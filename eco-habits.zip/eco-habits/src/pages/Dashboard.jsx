import React, { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Line, Doughnut } from "react-chartjs-2";
import confetti from "canvas-confetti";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  ArcElement,
  Tooltip,
  Legend,
  Filler
} from "chart.js";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  ArcElement,
  Tooltip,
  Legend,
  Filler
);

const Dashboard = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [progress, setProgress] = useState({});
  const [activityLog, setActivityLog] = useState([]);

  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    if (!storedUser) {
      navigate("/login");
    } else {
      const u = JSON.parse(storedUser);
      setUser(u);
      setProgress(u.progress || {});
      setActivityLog(u.activityLog || []);
    }
  }, [navigate]);

  const habitLabels = [
    "Reduce, Reuse or Recycle",
    "Save Water",
    "Sustainable Transportation",
    "Conserve Energy"
  ];

  const badgeConditions = useMemo(() => ({
    "🌱 Green Starter": Object.values(progress).reduce((a, b) => a + b, 0) >= 250,
    "💧 Water Hero": (progress["Save Water"] || 0) >= 500,
    "🌍 Eco Earner": (user?.rupeesEarned || 0) >= 250,
    "🎁 Monthly Lucky Draw": (user?.score || 0) >= 5000
  }), [progress, user]);

  useEffect(() => {
    Object.entries(badgeConditions).forEach(([title, unlocked]) => {
      if (unlocked && !localStorage.getItem(`${title}-shown`)) {
        confetti({ particleCount: 100, spread: 80 });
        localStorage.setItem(`${title}-shown`, true);
      }
    });
  }, [badgeConditions]);

  const donutData = {
    labels: habitLabels,
    datasets: [{
      data: habitLabels.map((label) => progress[label] || 0),
      backgroundColor: ["#4caf50", "#2196f3", "#ffc107", "#e91e63"],
      borderWidth: 2,
    }]
  };

  const today = new Date();
  const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  const last7 = Array.from({ length: 7 }).map((_, i) => {
    const d = new Date(today);
    d.setDate(d.getDate() - (6 - i));
    return d.toISOString().slice(0, 10);
  });

  const dailyScore = last7.map((date) =>
    activityLog
      .filter((log) => log.date === date)
      .reduce((sum, log) => sum + (log.score || 0), 0)
  );

  const dailyData = {
    labels: last7.map((date) => dayNames[new Date(date).getDay()]),
    datasets: [
      {
        label: "Daily Eco Score",
        data: dailyScore,
        borderColor: "#198754",
        backgroundColor: "rgba(25, 135, 84, 0.2)",
        fill: true,
        tension: 0.4,
        pointBackgroundColor: "#198754",
        pointBorderColor: "#198754"
      }
    ]
  };

  const totalScore = user?.score || 0;
  const rupeesEarned = user?.rupeesEarned || 0;

  const handleConvertScore = () => {
    if (!user || totalScore < 1000) {
      alert("❌ You need at least 1000 points to convert.");
      return;
    }

    const updatedUser = {
      ...user,
      score: totalScore - 1000,
      rupeesEarned: rupeesEarned + 50
    };

    localStorage.setItem("user", JSON.stringify(updatedUser));
    const allUsers = JSON.parse(localStorage.getItem("users")) || [];
    const updatedUsers = allUsers.map((u) =>
      u.email === user.email ? updatedUser : u
    );
    localStorage.setItem("users", JSON.stringify(updatedUsers));

    setUser(updatedUser);
    confetti({ particleCount: 120, spread: 70 });
    alert("🎉 You converted 1000 points into 50 rupees!");
  };

  return (
    <div className="container py-5" style={{ minHeight: "120vh" }}>
      <div className="mb-4 text-center">
        <h2 className="fw-bold text-success animate__animated animate__fadeInDown">
          Welcome, {user?.name || "Eco Hero"}! 🌱
        </h2>
        <p className="lead text-muted">
          Here's your monthly performance and impact on the planet.
        </p>
      </div>

      <div className="text-center mb-5">
        <div className="display-6 fw-bold text-primary">
          🌍 Total Eco Score: <span className="text-success">{totalScore}</span>
        </div>
        <div className="fs-5 mt-2 text-secondary">
          💰 Rupees Earned: <strong>{rupeesEarned} PKR</strong>
        </div>
        {totalScore >= 1000 && (
          <button
            onClick={handleConvertScore}
            className="btn btn-warning mt-3 px-4 py-2 rounded-pill"
          >
            Convert 1000 Points ➜ 50 Rupees
          </button>
        )}
      </div>

      <div className="row g-4">
        <div className="col-md-6">
          <div className="card shadow rounded-4 p-4" style={{ height: "400px", display: "flex", flexDirection: "column" }}>
            <h5 className="text-success mb-3">📈 Weekly Eco Score</h5>
            <div style={{ flexGrow: 1 }}>
              <Line data={dailyData} options={{ responsive: true, maintainAspectRatio: false }} />
            </div>
          </div>
        </div>

        <div className="col-md-6">
          <div className="card shadow rounded-4 p-4" style={{ height: "400px", display: "flex", flexDirection: "column" }}>
            <h5 className="text-success mb-3">📊 Score Contribution by Habit</h5>
            <div style={{ flexGrow: 1 }}>
              <Doughnut data={donutData} options={{ responsive: true, maintainAspectRatio: false }} />
            </div>
          </div>
        </div>
      </div>

      <div className="mt-5">
        <h4 className="text-center text-success mb-4">🌿 Your Impact Breakdown</h4>
        <div className="row g-4">
          {habitLabels.map((label, idx) => (
            <div key={idx} className="col-md-3">
              <div className="card text-center border-0 shadow-sm rounded-4 p-3" style={{ minHeight: "120px" }}>
                <h6 className="fw-bold text-success">{label}</h6>
                <div className="fs-4 text-primary">{progress[label] || 0} pts</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-5">
        <h4 className="text-center text-success mb-4">🎖 Badge Progress Overview</h4>
        <div className="row g-4">
          {[
            {
              title: "🌱 Green Starter",
              current: Object.values(progress).reduce((a, b) => a + b, 0),
              goal: 250
            },
            {
              title: "💧 Water Hero",
              current: progress["Save Water"] || 0,
              goal: 500
            },
            {
              title: "🌍 Eco Earner",
              current: user?.rupeesEarned || 0,
              goal: 250
            },
            {
              title: "🎁 Lucky Draw Eligible",
              current: user?.score || 0,
              goal: 5000
            }
          ].map((badge, idx) => {
            const percent = Math.min((badge.current / badge.goal) * 100, 100).toFixed(0);
            return (
              <div className="col-md-6" key={idx}>
                <div className="card shadow-sm border-0 p-3">
                  <h6 className="text-success mb-1">{badge.title}</h6>
                  <div className="small text-muted mb-2">
                    {badge.current} / {badge.goal} pts
                  </div>
                  <div className="progress" style={{ height: "8px" }}>
                    <div
                      className="progress-bar bg-success"
                      role="progressbar"
                      style={{ width: `${percent}%` }}
                      aria-valuenow={badge.current}
                      aria-valuemin="0"
                      aria-valuemax={badge.goal}
                    ></div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="text-center mt-5">
        <button
          className="btn btn-outline-danger px-4 py-2 rounded-pill"
          onClick={() => {
            localStorage.removeItem("user");
            navigate("/login");
          }}
        >
          🚪 Logout
        </button>
      </div>
    </div>
  );
};

export default Dashboard;
