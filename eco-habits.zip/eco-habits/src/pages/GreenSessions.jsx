import React from 'react';

const GreenSessions = () => {
  // Video links array
  const videos = {
    sustainableLiving: "https://www.youtube.com/watch?v=PBkmOhOk8nk",
    digitalEcoSkills: "https://www.youtube.com/watch?v=yEV7oaT5pnw",
    climateAction: "https://www.youtube.com/watch?v=oOBoXbJLqrA",
    everydaySustainability: "https://www.youtube.com/watch?v=kZIrIQDf1nQ"
  };

  return (
    <div className="container py-5">
      <div className="text-center mb-4">
        <h2 className="display-5 fw-bold text-success">🌿 Green Sessions</h2>
        <p className="lead text-muted">
          Empower yourself with knowledge that protects our planet
        </p>
      </div>

      <div className="row g-4 mb-5">
        <div className="col-md-6 col-lg-3">
          <div className="card h-100 shadow-sm border-success">
            <div className="card-body text-center">
              <div className="display-4">♻️</div>
              <h4>Sustainable Living</h4>
              <p>Practical steps for eco-friendly daily life</p>
              <a 
                href={videos.sustainableLiving} 
                target="_blank" 
                rel="noopener noreferrer"
                className="btn btn-outline-success mt-2 w-100"
              >
                Watch Tutorial
              </a>
            </div>
          </div>
        </div>

        <div className="col-md-6 col-lg-3">
          <div className="card h-100 shadow-sm border-success">
            <div className="card-body text-center">
              <div className="display-4">💻</div>
              <h4>Digital Eco Skills</h4>
              <p>Using tech for environmental impact</p>
              <a 
                href={videos.digitalEcoSkills} 
                target="_blank" 
                rel="noopener noreferrer"
                className="btn btn-outline-success mt-2 w-100"
              >
                Learn More
              </a>
            </div>
          </div>
        </div>

        <div className="col-md-6 col-lg-3">
          <div className="card h-100 shadow-sm border-success">
            <div className="card-body text-center">
              <div className="display-4">🌍</div>
              <h4>Climate Action</h4>
              <p>How you can make a difference today</p>
              <a 
                href={videos.climateAction} 
                target="_blank" 
                rel="noopener noreferrer"
                className="btn btn-outline-success mt-2 w-100"
              >
                Take Action
              </a>
            </div>
          </div>
        </div>

        <div className="col-md-6 col-lg-3">
          <div className="card h-100 shadow-sm border-success">
            <div className="card-body text-center">
              <div className="display-4">🏡</div>
              <h4>Sustainable Homes</h4>
              <p>Eco-friendly living spaces</p>
              <a 
                href={videos.everydaySustainability} 
                target="_blank" 
                rel="noopener noreferrer"
                className="btn btn-outline-success mt-2 w-100"
              >
                View Guide
              </a>
            </div>
          </div>
        </div>
      </div>

      <div className="text-center mt-5">
        <div className="alert alert-success">
          <h4>Quick Video Resources</h4>
          <div className="d-flex flex-wrap justify-content-center gap-2 mt-3">
            <a href="https://www.youtube.com/watch?v=LxgMdjyw8uw" target="_blank" rel="noopener noreferrer" className="btn btn-sm btn-success">
              Fixing Climate Change
            </a>
            <a href="https://www.youtube.com/watch?v=X2YgM1Zw4_E" target="_blank" rel="noopener noreferrer" className="btn btn-sm btn-success">
              10 Environment Tips
            </a>
            <a href="https://www.youtube.com/watch?v=8yuscHiSiiU" target="_blank" rel="noopener noreferrer" className="btn btn-sm btn-success">
              Sustainable Lifestyles
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GreenSessions;
