import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import confetti from "canvas-confetti";
import "animate.css";

const ecoActions = [
  {
    title: "Reduce, Reuse or Recycle",
    icon: "♻️",
    score: 50,
    description: "Minimize waste by reusing items and recycling materials properly.",
    checklist: [
      "Properly sorted recycling materials",
      "Reused at least one item today",
      "Avoided single-use plastic",
      "Composted organic waste"
    ]
  },
  {
    title: "Save Water",
    icon: "💧",
    score: 50,
    description: "Turn off taps when not in use and fix leaks to conserve water.",
    checklist: [
      "Used faucet aerators",
      "Took a shower (<5 minutes)",
      "Collected rainwater for plants",
      "Fixed any leaky faucets"
    ]
  },
  {
    title: "Conserve Energy",
    icon: "⚡",
    score: 100,
    description: "Use energy-efficient appliances and turn off lights to save electricity.",
    checklist: [
      "Turned off unused lights",
      "Used natural light during day",
      "Unplugged unused electronics",
      "Lowered thermostat by 1°C"
    ]
  },
  {
    title: "Sustainable Transportation",
    icon: "🚴",
    score: 100,
    description: "Walk, bike, or use public transport to reduce carbon emissions.",
    checklist: [
      "Walked or biked today",
      "Used public transportation",
      "Carpooled with others",
      "Planned efficient routes"
    ]
  }
];

const EcoAction = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [selectedAction, setSelectedAction] = useState(null);
  const [completedChecks, setCompletedChecks] = useState([]);
  const today = new Date().toISOString().slice(0, 10);

  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    if (!storedUser) {
      navigate("/login");
    } else {
      setUser(JSON.parse(storedUser));
    }
  }, [navigate]);

  const showSuccessMessage = (title, points) => {
    const card = document.createElement("div");
    card.innerHTML = `
      <div style="
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: #dff0d8;
        color: #3c763d;
        border-left: 6px solid #4caf50;
        padding: 24px 32px;
        border-radius: 10px;
        box-shadow: 0 6px 20px rgba(0,0,0,0.3);
        z-index: 9999;
        font-size: 18px;
        max-width: 320px;
        text-align: center;
        animation: fadeInOut 4s ease-in-out forwards;
      ">
        <strong>🎉 Well Done!</strong><br />
        You earned <strong>${points}</strong> points<br />for "${title}" 🌿
      </div>
    `;
    document.body.appendChild(card);
    setTimeout(() => card.remove(), 4000);
    confetti({ particleCount: 100, spread: 70 });
  };

  const handleCheckboxChange = (item) => {
    setCompletedChecks(prev => 
      prev.includes(item)
        ? prev.filter(i => i !== item)
        : [...prev, item]
    );
  };

  const submitAction = () => {
    if (completedChecks.length === 0) {
      return;
    }

    const action = selectedAction;
    const updatedScore = (user.score || 0) + action.score;
    const updatedProgress = { ...(user.progress || {}) };
    updatedProgress[action.title] = (updatedProgress[action.title] || 0) + action.score;

    const activityLog = [...(user.activityLog || []), {
      date: today,
      action: action.title,
      score: action.score,
      checks: completedChecks
    }];

    const updatedUser = {
      ...user,
      score: updatedScore,
      progress: updatedProgress,
      activityLog
    };

    localStorage.setItem("user", JSON.stringify(updatedUser));
    const allUsers = JSON.parse(localStorage.getItem("users")) || [];
    const updatedUsers = allUsers.map(u => 
      u.email === user.email ? updatedUser : u
    );
    localStorage.setItem("users", JSON.stringify(updatedUsers));

    setUser(updatedUser);
    setSelectedAction(null);
    setCompletedChecks([]);
    showSuccessMessage(action.title, action.score);
  };

  return (
    <div className="container py-5 animate__animated animate__fadeIn">
      <div className="text-center mb-5">
        <h2 className="text-success mb-3">🌿 Daily Eco Actions</h2>
        <p className="text-muted">
          Complete eco-friendly actions and earn rewards. You can perform each action multiple times daily!
        </p>
      </div>

      <div className="row g-4 mb-5">
        {ecoActions.map((action, index) => (
          <div className="col-md-6 col-lg-3" key={index}>
            <div className="card h-100 border-0 shadow-sm hover-shadow transition-all">
              <div className="card-body text-center d-flex flex-column">
                <div className="display-4 mb-3">{action.icon}</div>
                <h5 className="text-success">{action.title}</h5>
                <small className="text-muted mb-3">{action.description}</small>
                <button
                  className="btn btn-outline-success mt-auto"
                  onClick={() => {
                    setSelectedAction(action);
                    setCompletedChecks([]);
                  }}
                >
                  Earn {action.score} Points
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Action Checklist Modal */}
      {selectedAction && (
        <div className="modal-backdrop d-flex justify-content-center align-items-center" 
          style={{ 
            position: 'fixed', 
            top: 0, 
            left: 0, 
            right: 0,
            bottom: 0,
            background: 'rgba(0,0,0,0.5)', 
            zIndex: 1050 
          }}>
          <div className="bg-white rounded-4 shadow-lg p-4 animate__animated animate__zoomIn" 
            style={{ 
              maxWidth: '500px', 
              width: '90%',
              maxHeight: '90vh',
              overflowY: 'auto'
            }}>
            
            <div className="d-flex justify-content-between align-items-center mb-3">
              <h5 className="text-success mb-0">{selectedAction.title}</h5>
              <button 
                className="btn-close" 
                onClick={() => setSelectedAction(null)}
                aria-label="Close"
              ></button>
            </div>
            
            <p className="text-muted mb-4">{selectedAction.description}</p>
            
            <h6 className="mb-3">What actions did you complete today?</h6>
            
            <ul className="list-group mb-4">
              {selectedAction.checklist.map((item, index) => (
                <li key={index} className="list-group-item border-0 px-0 py-2">
                  <div className="form-check">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id={`check-${index}`}
                      checked={completedChecks.includes(item)}
                      onChange={() => handleCheckboxChange(item)}
                    />
                    <label className="form-check-label" htmlFor={`check-${index}`}>
                      {item}
                    </label>
                  </div>
                </li>
              ))}
            </ul>
            
            <div className="d-grid gap-2 d-md-flex justify-content-md-end">
              <button 
                className="btn btn-outline-secondary me-md-2"
                onClick={() => setSelectedAction(null)}
              >
                Cancel
              </button>
              <button 
                className="btn btn-success"
                onClick={submitAction}
                disabled={completedChecks.length === 0}
              >
                Confirm & Earn {selectedAction.score} Points
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default EcoAction;
