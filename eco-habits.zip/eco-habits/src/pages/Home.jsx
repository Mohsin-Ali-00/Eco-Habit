import React from 'react';

const Home = () => {
  return (
    <div className="container-fluid bg-light py-5">
      <div className="row align-items-center px-4">
        <div className="col-md-6">
          <h1 className="display-4 fw-bold text-success">Welcome to Eco Habits 🌍</h1>
          <p className="lead text-muted">
            Small steps, big impact. Join us in making everyday choices that protect the Earth and secure a greener future for all.
          </p>
          <a href="/get-involved" className="btn btn-success btn-lg mt-3">
            Get Involved Now
          </a>
        </div>
        <div className="col-md-6 text-center">
          <img
            src="ECO-Habits.jpg"
            alt="Eco Illustration"
            className="img-fluid"
            style={{ maxHeight: '300px' }}
          />
        </div>
      </div>
    </div>
  );
};

export default Home;
