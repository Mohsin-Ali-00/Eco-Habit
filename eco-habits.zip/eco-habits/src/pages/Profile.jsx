import React, { useEffect, useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";

const badgesList = [
  {
    id: "starter",
    name: "🌱 Green Starter",
    condition: (progress) =>
      Object.values(progress || {}).reduce((a, b) => a + b, 0) >= 250,
  },
  {
    id: "water",
    name: "💧 Water Hero",
    condition: (progress) => (progress?.["Save Water"] || 0) >= 500,
  },
  {
    id: "ecoearner",
    name: "🌍 Eco Earner",
    condition: (user) => user?.rupeesEarned >= 250,
  },
  {
    id: "lucky",
    name: "🎁 Lucky Draw Eligible",
    condition: (user) => (user?.score || 0) >= 5000,
  },
];

const Profile = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const certificateRef = useRef();

  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem("user"));
    if (!storedUser) {
      navigate("/login");
    } else {
      setUser(storedUser);
    }
  }, [navigate]);

  const generatePDF = () => {
    const input = certificateRef.current;
    html2canvas(input).then((canvas) => {
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF("landscape", "mm", "a4");
      pdf.addImage(imgData, "PNG", 10, 10, 277, 190);
      pdf.save(`${user.name.replace(/\s+/g, "_")}_certificate.pdf`);
    });
  };

  if (!user) return <div className="text-center mt-5">Loading profile...</div>;

  const allUnlocked = badgesList.every((badge) =>
    badge.condition(user.progress || user)
  );

  return (
    <div className="container py-5">
      <h2 className="text-success mb-4 text-center animate__animated animate__fadeInDown">
        👤 {user.name}
      </h2>

      <div className="mb-4">
        <p><strong>Email:</strong> {user.email}</p>
        <p><strong>Total Score:</strong> {user.score || 0}</p>
        <p><strong>Rupees Earned:</strong> {user.rupeesEarned || 0} PKR</p>
      </div>

      <div className="my-5">
        <h4 className="text-success">🌿 My Badges</h4>
        <div className="row g-3">
          {badgesList.map((badge) => {
            const unlocked = badge.condition(user.progress || user);
            return (
              <div className="col-md-3" key={badge.id}>
                <div className={`card p-3 text-center shadow-sm ${unlocked ? "border-success" : "border-secondary"}`}>
                  <h6 className={unlocked ? "text-success" : "text-muted"}>
                    {badge.name}
                  </h6>
                  <span>{unlocked ? "✅ Unlocked" : "🔒 Locked"}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {allUnlocked ? (
        <>
          <div className="text-center mt-4">
            <button onClick={generatePDF} className="btn btn-success">
              🎉 Download My Certificate
            </button>
          </div>

          {/* Hidden Certificate Template */}
          <div
            ref={certificateRef}
            style={{
              width: "1000px",
              height: "700px",
              background: "#fff",
              color: "#333",
              padding: "50px",
              border: "2px solid green",
              margin: "40px auto",
              display: "none",
            }}
          >
            <h1 style={{ textAlign: "center", color: "#198754" }}>
              🌿 Eco Habits Achievement Certificate
            </h1>
            <hr />
            <p style={{ fontSize: "22px", textAlign: "center", marginTop: "60px" }}>
              This is proudly presented to
            </p>
            <h2 style={{ textAlign: "center", fontSize: "36px" }}>
              {user.name}
            </h2>
            <p style={{ fontSize: "18px", textAlign: "center", marginTop: "30px" }}>
              For completing all eco actions and earning all badges as part of the
              Eco Habits initiative.
            </p>
            <p style={{ textAlign: "center", marginTop: "50px" }}>
              🗓 Issued on: {new Date().toLocaleDateString()}
            </p>
            <div style={{ textAlign: "right", marginTop: "80px", fontStyle: "italic" }}>
              — Eco Habits Team
            </div>
          </div>
        </>
      ) : (
        <div className="text-center mt-4">
          <p className="text-muted">
            📜 Badge Certificate will be available when all badges are unlocked.
          </p>
        </div>
      )}
    </div>
  );
};

export default Profile;
