import React, { useState } from 'react';

const GetInvolved = () => {
  const [showVolunteerForm, setShowVolunteerForm] = useState(false);
  const [showCreativeForm, setShowCreativeForm] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);

  const handleVolunteerClick = () => {
    setShowVolunteerForm(true);
    setShowCreativeForm(false);
    setShowShareModal(false);
  };

  const handleCreativeClick = () => {
    setShowCreativeForm(true);
    setShowVolunteerForm(false);
    setShowShareModal(false);
  };

  const handleShareClick = () => {
    setShowShareModal(true);
    setShowVolunteerForm(false);
    setShowCreativeForm(false);
  };

  return (
    <div className="container py-5">
      <div className="text-center mb-4">
        <h2 className="display-5 fw-bold text-success">Get Involved</h2>
        <p className="lead text-muted">
          Turn your awareness into action. Join the movement to protect our planet.
        </p>
      </div>

      <div className="row g-4">
        <div className="col-md-4">
          <div className="card h-100 border-0 shadow-sm">
            <div className="card-body">
              <h5 className="card-title text-success">🌱 Volunteer</h5>
              <p className="card-text">
                Join local clean-up drives, awareness campaigns, and tree-planting events organized by Eco Habits.
              </p>
              <button onClick={handleVolunteerClick} className="btn btn-outline-success btn-sm">
                Sign Up
              </button>
            </div>
          </div>
        </div>

        <div className="col-md-4">
          <div className="card h-100 border-0 shadow-sm">
            <div className="card-body">
              <h5 className="card-title text-success">🎨 Contribute Creatively</h5>
              <p className="card-text">
                Use your digital skills — design, write, code, or animate to spread eco-awareness through social media and events.
              </p>
              <button onClick={handleCreativeClick} className="btn btn-outline-success btn-sm">
                Join Creative Team
              </button>
            </div>
          </div>
        </div>

        <div className="col-md-4">
          <div className="card h-100 border-0 shadow-sm">
            <div className="card-body">
              <h5 className="card-title text-success">📢 Share Our Message</h5>
              <p className="card-text">
                Become a digital advocate. Share our tips, sessions, and resources with friends, family, and community groups.
              </p>
              <button onClick={handleShareClick} className="btn btn-outline-success btn-sm">
                Share Now
              </button>
            </div>
          </div>
        </div>
      </div>

      {showVolunteerForm && (
        <div className="mt-5 p-4 bg-light rounded shadow-sm" id="volunteer-form">
          <h4 className="text-success">🌍 Join Us Today</h4>
          <p className="text-muted">Fill out your interest below, and we’ll reach out with upcoming opportunities.</p>

          <form>
            <div className="mb-3">
              <label className="form-label">Full Name</label>
              <input type="text" className="form-control" placeholder="Your name" required />
            </div>
            <div className="mb-3">
              <label className="form-label">Email Address</label>
              <input type="email" className="form-control" placeholder="your@email.com" required />
            </div>
            <div className="mb-3">
              <label className="form-label">Upload Picture</label>
              <input type="file" className="form-control" accept="image/*" required />
            </div>
            <div className="mb-3">
              <label className="form-label">Gender</label>
              <div>
                <label className="form-check-label me-3">
                  <input type="radio" name="gender" value="male" className="form-check-input" required /> Male
                </label>
                <label className="form-check-label">
                  <input type="radio" name="gender" value="female" className="form-check-input" required /> Female
                </label>
              </div>
            </div>
            <div className="mb-3">
              <label className="form-label">Marital Status</label>
              <div>
                <label className="form-check-label me-3">
                  <input type="radio" name="maritalStatus" value="single" className="form-check-input" required /> Single
                </label>
                <label className="form-check-label me-3">
                  <input type="radio" name="maritalStatus" value="married" className="form-check-input" required /> Married
                </label>
                <label className="form-check-label">
                  <input type="radio" name="maritalStatus" value="divorced" className="form-check-input" required /> Divorced
                </label>
              </div>
            </div>
            <div className="mb-3">
              <label className="form-label">Date of Birth</label>
              <input type="date" className="form-control" required />
            </div>
            <div className="mb-3">
              <label className="form-label">Contact Number</label>
              <input type="tel" className="form-control" placeholder="Your contact number" required />
            </div>
            <div className="mb-3">
              <label className="form-label">Postal Address</label>
              <input type="text" className="form-control" placeholder="Your postal address" required />
            </div>
            <div className="mb-3">
              <label className="form-label">National ID Number</label>
              <input type="text" className="form-control" placeholder="Your National ID number" required />
            </div>
            <div className="mb-3">
              <label className="form-label">Interest Area</label>
              <select className="form-select">
                <option>Volunteering</option>
                <option>Design & Digital</option>
                <option>Spreading Awareness</option>
              </select>
            </div>
            <div className="mb-3">
              <label className="form-label">Skills</label>
              <input type="text" className="form-control" placeholder="Your skills (e.g., communication, leadership)" required />
            </div>
            <div className="mb-3">
              <label className="form-label">Availability</label>
              <input type="text" className="form-control" placeholder="Days and times available" required />
            </div>
            <div className="mb-3">
              <label className="form-label">Do you have any disabilities?</label>
              <div>
                <label className="form-check-label me-3">
                  <input type="radio" name="disability" value="yes" className="form-check-input" required /> Yes
                </label>
                <label className="form-check-label">
                  <input type="radio" name="disability" value="no" className="form-check-input" required /> No
                </label>
              </div>
            </div>
            <div className="mb-3">
              <label className="form-label">If yes, please specify:</label>
              <textarea className="form-control" placeholder="Please specify if any" rows="3"></textarea>
            </div>
            <button type="submit" className="btn btn-success">Submit</button>
          </form>
        </div>
      )}

      {showCreativeForm && (
        <div className="mt-5 p-4 bg-light rounded shadow-sm" id="creative-form">
          <h4 className="text-success">🎨 Join the Creative Team</h4>
          <p className="text-muted">Share your creative skills with us!</p>

          <form>
            <div className="mb-3">
              <label className="form-label">Full Name</label>
              <input type="text" className="form-control" placeholder="Your name" required />
            </div>
            <div className="mb-3">
              <label className="form-label">Email Address</label>
              <input type="email" className="form-control" placeholder="your@email.com" required />
            </div>
            <div className="mb-3">
              <label className="form-label">Skills</label>
              <input type="text" className="form-control" placeholder="Your skills" required />
            </div>
            <button type="submit" className="btn btn-success">Submit</button>
          </form>
        </div>
      )}

      {showShareModal && (
        <div className="mt-5 p-4 bg-light rounded shadow-sm">
          <h4 className="text-success">📢 Share Our Message</h4>
          <p className="text-muted">Choose a platform to share:</p>
          <a href="https://www.instagram.com" target="_blank" rel="noreferrer" className="btn btn-outline-success btn-sm">
            Share on Instagram
          </a>
          <a href="https://www.facebook.com" target="_blank" rel="noreferrer" className="btn btn-outline-success btn-sm">
            Share on Facebook
          </a>
          <a href="https://www.twitter.com" target="_blank" rel="noreferrer" className="btn btn-outline-success btn-sm">
            Share on Twitter
          </a>
        </div>
      )}
    </div>
  );
};

export default GetInvolved;
