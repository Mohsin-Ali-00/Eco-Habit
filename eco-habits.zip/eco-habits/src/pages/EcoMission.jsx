import React from 'react';

const EcoMission = () => {
  return (
    <div className="container py-5">
      <div className="text-center mb-4">
        <h2 className="display-5 fw-bold text-success">Our Eco Mission</h2>
        <p className="lead text-muted">
          Building a world where sustainability is a shared habit, not a challenge.
        </p>
      </div>

      <div className="row g-4">
        <div className="col-md-6">
          <h4 className="text-success">🌍 Why We Exist</h4>
          <p>
            Eco Habits exists to inspire, educate, and empower individuals to take responsibility for their environmental impact through digital education and practical eco-actions.
          </p>
        </div>

        <div className="col-md-6">
          <h4 className="text-success">📘 How We Do It</h4>
          <p>
            Through sessions, challenges, eco content creation, and community involvement, we foster a space where climate action becomes a lifestyle, not a task.
          </p>
        </div>
      </div>

      <div className="mt-5 p-4 bg-light rounded shadow-sm">
        <h5 className="text-success">Join the Movement</h5>
        <ul className="list-unstyled">
          <li>✅ Empowering youth with green skills</li>
          <li>✅ Using digital platforms for climate outreach</li>
          <li>✅ Encouraging tech-based eco innovations</li>
        </ul>
      </div>
    </div>
  );
};

export default EcoMission;
