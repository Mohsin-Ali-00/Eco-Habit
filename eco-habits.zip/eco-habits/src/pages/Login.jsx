import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const Login = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [showModal, setShowModal] = useState(false);

  const handleLogin = (e) => {
    e.preventDefault();
    setError("");

    const users = JSON.parse(localStorage.getItem("users")) || [];
    const foundUser  = users.find(
      (user) =>
        user.email.toLowerCase() === email.trim().toLowerCase() &&
        user.password === password
    );

    if (foundUser ) {
      localStorage.setItem("user", JSON.stringify(foundUser ));
      navigate("/dashboard");
    } else {
      setError("Invalid email or password.");
    }
  };

  const handleForgotPassword = () => {
    setShowModal(true); // Show the modal
  };

  const handleCloseModal = () => {
    setShowModal(false); // Close the modal
  };

  const handleResetPassword = (e) => {
    e.preventDefault();
    // Logic to handle password reset (e.g., send email)
    alert(`Password reset link sent to ${email}`);
    handleCloseModal(); // Close the modal after sending the link
  };

  return (
    <div className="container py-5">
      <h2 className="text-center text-success mb-4">Login to Eco Habits</h2>
      {error && <div className="alert alert-danger">{error}</div>}

      <form onSubmit={handleLogin} className="mx-auto" style={{ maxWidth: "500px" }}>
        <div className="mb-3">
          <label>Email address</label>
          <input
            type="email"
            className="form-control"
            placeholder="you@example.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>

        <div className="mb-3">
          <label>Password</label>
          <input
            type="password"
            className="form-control"
            placeholder="Enter password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            minLength={4}
            required
          />
        </div>

        <button type="submit" className="btn btn-success w-100">Login</button>
      </form>

      <div className="text-center mt-3">
        <button onClick={handleForgotPassword} className="btn btn-link">Forgot Password?</button>
      </div>

      {/* Modal for Forgot Password */}
      {showModal && (
        <div className="modal show" style={{ display: "block" }}>
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Reset Password</h5>
                <button type="button" className="btn-close" onClick={handleCloseModal}></button>
              </div>
              <div className="modal-body">
                <form onSubmit={handleResetPassword}>
                  <div className="mb-3">
                    <label>Email address</label>
                    <input
                      type="email"
                      className="form-control"
                      placeholder="you@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                    />
                  </div>
                  <button type="submit" className="btn btn-success w-100">Send Reset Link</button>
                </form>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Login;
