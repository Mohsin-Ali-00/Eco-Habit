import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

const Navbar = () => {
  const user = JSON.parse(localStorage.getItem("user"));
  const navigate = useNavigate();
  const [isNavOpen, setIsNavOpen] = useState(false);

  const handleLogout = () => {
    localStorage.removeItem("user");
    navigate("/login");
  };

  const toggleNavbar = () => {
    setIsNavOpen(!isNavOpen);
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-success px-4 shadow-sm">
      <Link to="/" className="navbar-brand text-white fw-bold d-flex align-items-center">
        <img src={`${process.env.PUBLIC_URL}/logo.png`} alt="Eco Habit Logo" style={{ width: '40px', height: '40px', marginRight: '8px' }} />
        ECO-HABIT
      </Link>
      {!user ? (
        <>
        </>
      ) : (
        <>
          <span className="text-white mx-2 fw-bold">
            👋 Welcome, {user.name?.split(" ")[0] || "Eco Hero"}!
          </span>
        </>
      )}
      <button
        className="navbar-toggler text-white border-white"
        type="button"
        onClick={toggleNavbar}
        aria-controls="navbarNav"
        aria-expanded={isNavOpen}
        aria-label="Toggle navigation"
      >
        <span className="navbar-toggler-icon"></span>
      </button>

      <div className={`collapse navbar-collapse ${isNavOpen ? "show" : ""}`} id="navbarNav">
        <div className="ms-auto d-lg-flex align-items-center">
          <Link to="/" className="btn btn-outline-light mx-1 my-1 my-lg-0">Home</Link>
          <Link to="/green-sessions" className="btn btn-outline-light mx-1 my-1 my-lg-0">Green Sessions</Link>
          <Link to="/eco-mission" className="btn btn-outline-light mx-1 my-1 my-lg-0">Eco Mission</Link>

          {!user ? (
            <>
              <Link to="/registration" className="btn btn-outline-light mx-1 my-1 my-lg-0">Register</Link>
              <Link to="/login" className="btn btn-warning mx-1 my-1 my-lg-0">Login</Link>
            </>
          ) : (
            <>
              <Link to="/eco-action" className="btn btn-outline-light mx-1 my-1 my-lg-0">Eco Action</Link>
              <Link to="/dashboard" className="btn btn-outline-light mx-1 my-1 my-lg-0">Dashboard</Link>
              <Link to="/profile" className="btn btn-outline-light mx-1 my-1 my-lg-0">Profile</Link>
              <button onClick={handleLogout} className="btn btn-danger mx-1 my-1 my-lg-0">Logout</button>
            </>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
