import React from 'react';

const Footer = () => {
  return (
    <footer className="bg-success text-white py-4 mt-5">
      <div className="container text-center">
        <p className="mb-1 fw-bold">🌍 Together for a Greener Tomorrow</p>
        <p className="mb-1">
          Every small eco habit you adopt brings us one step closer to a sustainable planet.
        </p>
        <p className="mb-1">
          Contact at: mohsin.soomro2000@gmail.com
        </p>
        <small className="d-block mt-2">
          &copy; {new Date().getFullYear()} Eco Habits. All rights reserved.
        </small>
      </div>
    </footer>
  );
};

export default Footer;
